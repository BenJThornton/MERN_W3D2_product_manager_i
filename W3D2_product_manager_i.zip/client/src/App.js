import logo from './logo.svg';
import './App.css';
import Main from './views/Main';
import {Link, Switch, Route, Redirect} from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <h1>Products</h1>
      <div>
          <Link to='/'>Home</Link> &nbsp;&nbsp;&nbsp;
          <Link to='/products/new'>Create</Link>
      </div>
      <hr/>
      <Main/>


      <Switch>
        <Route path='/products'>
            
        </Route>
      </Switch>
    </div>
  );
}

export default App;
